# Local VLM offline comparison

These are actual generated outputs. Annotation agreement is not live GUI success.

Primary prompt: `original`. Validation-selected prompt: `original`.

| Split | Weights | Prompt | Schema valid | Types | Other parameters | Pointer targets | Annotation match |
|---|---|---|---|---|---|---|---|
| validation | best | original | 0/2 | 0/2 | 0/2 | 0/1 | 0/2 |
| validation | best | schema_v1 | 0/2 | 0/2 | 0/2 | 0/1 | 0/2 |
| test | base | original | 0/2 | 0/2 | 0/2 | 0/2 | 0/2 |
| test | best | original | 0/2 | 0/2 | 0/2 | 0/2 | 0/2 |
| test | final | original | 0/2 | 0/2 | 0/2 | 0/2 | 0/2 |

## Raw examples

### 1. validation / best / original

Sample: `screenagent:screenagent/05f7b82ed5d74dbe9c7888b427fcc571/2023-12-19_13-57-49-435932_translate.json`

![Actual fixed input screenshot](cases/validation/best/original/01/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "button": "left",
      "clicks": 2,
      "point": [
        59.0,
        42.0
      ],
      "type": "click"
    }
  ]
}
```

Raw generated response:

```text
 Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task: Find the next annotated GUI action(s) for this screenshot and task.

Task:
```

Error: `invalid_json`; tokens: 192; token limit hit: True; generation seconds: 40.296067.

[Full case, scores, prompt and generated tokens](cases/validation/best/original/01/result.json)

### 2. validation / best / original

Sample: `screenagent:screenagent/05f7b82ed5d74dbe9c7888b427fcc571/2023-12-19_13-59-50-928108_translate.json`

![Actual fixed input screenshot](cases/validation/best/original/02/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "text": "www.bing.com",
      "type": "type_text"
    },
    {
      "key": "enter",
      "type": "press"
    }
  ]
}
```

Raw generated response:

```text
 Task: To bake a chocolate cake, you need to follow these steps:
1. Open a new tab in the web browser.
2. In the search bar, type "how to bake a chocolate cake".
3. In the search results, look for the "baking" tab.
4. Click on the "baking" tab.
5. In the "baking" tab, click on the "bake" button.
6. Click on the "bake" button.
7. Click on the "bake" button.
8. Click on the "bake" button.
9. Click on the "bake" button.
10. Click on the "bake" button.
11. Click on the "bake" button.
12. Click on the "bake" button.
13. Click on the "bake" button
```

Error: `invalid_json`; tokens: 192; token limit hit: True; generation seconds: 25.403102.

[Full case, scores, prompt and generated tokens](cases/validation/best/original/02/result.json)

### 3. validation / best / schema_v1

Sample: `screenagent:screenagent/05f7b82ed5d74dbe9c7888b427fcc571/2023-12-19_13-57-49-435932_translate.json`

![Actual fixed input screenshot](cases/validation/best/schema_v1/01/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "button": "left",
      "clicks": 2,
      "point": [
        59.0,
        42.0
      ],
      "type": "click"
    }
  ]
}
```

Raw generated response:

```text
 Task: In www.bing.com, search for 'How to bake a chocolate cake'.

Output: {
    "type":"click","point":[x,y],"button":"left","clicks":1;
    "button":"left","clicks":2;
    "button":"left","button":"click","click":"1";
    "button":"left","button":"click","click":"2";
    "button":"left","button":"click","click":"3";
    "button":"left","button":"click","click":"4";
    "button":"left","button":"click","click":"5";
    "button":"left","button":"click","click":"6";
    "button":"left","button":"click","click":"7";
    "button":"left","button":"click","click":"8";
    "button":"left","button":"click","click":"9";
    "button":"left","button":"
```

Error: `invalid_json`; tokens: 192; token limit hit: True; generation seconds: 25.744993.

[Full case, scores, prompt and generated tokens](cases/validation/best/schema_v1/01/result.json)

### 4. validation / best / schema_v1

Sample: `screenagent:screenagent/05f7b82ed5d74dbe9c7888b427fcc571/2023-12-19_13-59-50-928108_translate.json`

![Actual fixed input screenshot](cases/validation/best/schema_v1/02/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "text": "www.bing.com",
      "type": "type_text"
    },
    {
      "key": "enter",
      "type": "press"
    }
  ]
}
```

Raw generated response:

```text
 Task: In www.bing.com, search for 'How to bake a chocolate cake'.
Output: {'type":"click","point":[x,y],"button":"left","clicks":1}; {"type":"move","point":[x,y]}; {"type":"drag","from":[x,y],"to":[x,y],"button":"left"}; {"type":"scroll","direction":"up or down","notches":positive_integer"}; {"type":"type_text","text":"text to type"}; {"type":"press","key":"key name"}; {"type":"hotkey","keys":["modifier","key"]}; {"type":"wait","seconds":nonnegative_number}. x and y are numeric ORIGINAL screenshot pixels inside the image.
```

Error: `invalid_json`; tokens: 171; token limit hit: False; generation seconds: 23.299348.

[Full case, scores, prompt and generated tokens](cases/validation/best/schema_v1/02/result.json)

### 5. test / base / original

Sample: `screenagent:screenagent/0410d62ce5074ee18b38078dd687b8ca/2023-12-25_10-54-19-019103_translate.json`

![Actual fixed input screenshot](cases/test/base/original/01/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "point": [
        450.0,
        394.0
      ],
      "type": "move"
    },
    {
      "button": "left",
      "from": [
        450.0,
        394.0
      ],
      "to": [
        573.0,
        407.0
      ],
      "type": "drag"
    }
  ]
}
```

Raw generated response:

```text
 {
    "actions": [
        {
            "name": "You're on a roll",
            "description": "Here, I'm a slightly harder puzzle for you to play."
        },
        {
            "name": "Here",
            "description": "I'm a slightly harder puzzle for you to play."
        }
    ],
    "interactions": [
        {
            "name": "Task"
        },
        {
            "name": "Pause"
        }
    ],
    "executions": [
        {
            "name": "You're on a roll"
        },
        {
            "name": "Here",
            "description": "I'm a slightly harder puzzle for you to play."
        },
        {
            "name": "Here",
            "description": "I'm a slightly harder puzzle for you to play."
        }
    ],
    "next_actions": [
        {
            "name": "Pause
```

Error: `invalid_json`; tokens: 192; token limit hit: True; generation seconds: 18.961074.

[Full case, scores, prompt and generated tokens](cases/test/base/original/01/result.json)

### 6. test / base / original

Sample: `screenagent:screenagent/0410d62ce5074ee18b38078dd687b8ca/2023-12-25_10-56-16-404347_translate.json`

![Actual fixed input screenshot](cases/test/base/original/02/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "point": [
        401.0,
        448.0
      ],
      "type": "move"
    },
    {
      "button": "left",
      "from": [
        401.0,
        448.0
      ],
      "to": [
        525.0,
        336.0
      ],
      "type": "drag"
    }
  ]
}
```

Raw generated response:

```text
 {
    "actions": [
        {
            "action": "You're on a roll",
            "text": "Here is a slightly harder puzzle for you to play to..."
        },
        {
            "action": "Press space to start the game",
            "text": "Press space to start the game"
        }
    ],
    "interactive": {
        "type": "text-input",
        "value": "Here is a slightly harder puzzle for you to play to..."
    }
}
```

Error: `invalid_action_schema`; tokens: 105; token limit hit: False; generation seconds: 9.57086.

[Full case, scores, prompt and generated tokens](cases/test/base/original/02/result.json)

### 7. test / best / original

Sample: `screenagent:screenagent/0410d62ce5074ee18b38078dd687b8ca/2023-12-25_10-54-19-019103_translate.json`

![Actual fixed input screenshot](cases/test/best/original/01/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "point": [
        450.0,
        394.0
      ],
      "type": "move"
    },
    {
      "button": "left",
      "from": [
        450.0,
        394.0
      ],
      "to": [
        573.0,
        407.0
      ],
      "type": "drag"
    }
  ]
}
```

Raw generated response:

```text
 {
    "actions": [
        {
            "action": "You're on a roll",
            "target": {
                "x": "100"
            },
            "score": "30"
        },
        {
            "action": "Here",
            "target": {
                "x": "100"
            },
            "score": "30"
        }
    ],
    "interactions": [
        {
            "type": "click",
            "action": "Do something"
        },
        {
            "type": "click",
            "action": "Do something"
        }
    ]
}
```

Error: `invalid_action_schema`; tokens: 131; token limit hit: False; generation seconds: 16.025091.

[Full case, scores, prompt and generated tokens](cases/test/best/original/01/result.json)

### 8. test / best / original

Sample: `screenagent:screenagent/0410d62ce5074ee18b38078dd687b8ca/2023-12-25_10-56-16-404347_translate.json`

![Actual fixed input screenshot](cases/test/best/original/02/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "point": [
        401.0,
        448.0
      ],
      "type": "move"
    },
    {
      "button": "left",
      "from": [
        401.0,
        448.0
      ],
      "to": [
        525.0,
        336.0
      ],
      "type": "drag"
    }
  ]
}
```

Raw generated response:

```text
 {
    "actions": [
        {
            "action": "You're on a roll",
            "text": "Here is a slightly harder puzzle for you to play to..."
        },
        {
            "action": "Press space to start the game",
            "text": "Press space to start the game"
        }
    ],
    "interactive": {
        "type": "text-input",
        "text": "Here is a slightly harder puzzle for you to play to..."
    }
}
```

Error: `invalid_action_schema`; tokens: 105; token limit hit: False; generation seconds: 13.567569.

[Full case, scores, prompt and generated tokens](cases/test/best/original/02/result.json)

### 9. test / final / original

Sample: `screenagent:screenagent/0410d62ce5074ee18b38078dd687b8ca/2023-12-25_10-54-19-019103_translate.json`

![Actual fixed input screenshot](cases/test/final/original/01/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "point": [
        450.0,
        394.0
      ],
      "type": "move"
    },
    {
      "button": "left",
      "from": [
        450.0,
        394.0
      ],
      "to": [
        573.0,
        407.0
      ],
      "type": "drag"
    }
  ]
}
```

Raw generated response:

```text
 {
    "actions": [
        {
            "action": "You're on a roll",
            "description": "Here, I'm a slightly harder puzzle for you to play."
        },
        {
            "action": "Here",
            "description": "I'm a slightly harder puzzle for you to play."
        }
    ],
    "interactions": [
        {
            "type": "action",
            "name": "You're on a roll"
        },
        {
            "type": "action",
            "name": "Here"
        }
    ],
    "executions": [
        {
            "action": "You're on a roll"
        },
        {
            "action": "Here"
        }
    ]
}
```

Error: `invalid_action_schema`; tokens: 153; token limit hit: False; generation seconds: 20.058347.

[Full case, scores, prompt and generated tokens](cases/test/final/original/01/result.json)

### 10. test / final / original

Sample: `screenagent:screenagent/0410d62ce5074ee18b38078dd687b8ca/2023-12-25_10-56-16-404347_translate.json`

![Actual fixed input screenshot](cases/test/final/original/02/input.png)

Reference annotation (never placed in the model input):

```json
{
  "actions": [
    {
      "point": [
        401.0,
        448.0
      ],
      "type": "move"
    },
    {
      "button": "left",
      "from": [
        401.0,
        448.0
      ],
      "to": [
        525.0,
        336.0
      ],
      "type": "drag"
    }
  ]
}
```

Raw generated response:

```text
 {
    "actions": [
        {
            "action": "You're on a roll",
            "text": "Here is a slightly harder puzzle for you to play."
        },
        {
            "action": "Press space to start the game",
            "text": "Press space to start the game"
        }
    ],
    "interactive": {
        "type": "text-input",
        "text": "Here is a slightly harder puzzle for you to play."
    }
}
```

Error: `invalid_action_schema`; tokens: 103; token limit hit: False; generation seconds: 12.646427.

[Full case, scores, prompt and generated tokens](cases/test/final/original/02/result.json)
