# GUI Agent v2.0.0 开发里程碑说明

版本标识位于 `gui_agent/version.py`。本版本汇总感知、规划、双通道执行、有界恢复、小规模 LoRA 与离线效果比较，新增点击前最新 OCR 重选和鲁棒性验证。它表示工程开发里程碑，模型能力、真实桌面与应用覆盖分别验收。

## 已完成

- 观察/定位次数和时间预算、全局计数、零输入有限重规划。
- 每个动作前复核状态及窗口；点击前同时核对最新 OCR 目标与新鲜图块。
- 部分输入/提交不确定性保守停止，失败后只读诊断；OCR 与独立状态共同确认最终目标。
- 子任务依赖和执行台账，失败分类、原始证据及完整性清单。
- 本地数据审计、LoRA 训练与断点恢复、基础/微调模型对照；质量失败原样保留。
- 342 项全项目测试、20 组新增鲁棒性和 30 组恢复/HTTP 回归通过各自预期。

## 本轮重要修复

旧版点击前可能继续使用第一次 OCR 的坐标和唯一性判断。新增目标重选后，位置变化会重定位，缺失会有限重试，重名歧义会停止。保留三个旧版实际模拟运行与新版本对照，见 [周五验证记录](../第三周周五任务验证记录.md)。图块指标和 OCR 重选都不是原子 UI 锁，真实桌面仍需要独立验收。

## 交付与复现

```powershell
.\.venv\Scripts\python.exe scripts/check_project.py --with-evidence
.\.venv\Scripts\python.exe run_robustness.py --scenario layout_moves
.\.venv\Scripts\python.exe scripts/validate_week3_friday.py --audit-only output/week3-friday/20261106T062447_279065Z
.\.venv\Scripts\python.exe scripts/build_v2_release.py --desktop-deferred-by-user
```

源码 ZIP 为 `output/deliverables/gui-agent-v2.0.0-<时间戳>.zip`，每个源码文件有 SHA-256 清单；版本记录位于 `output/releases/gui-agent-v2.0.0/<UTC时间戳>/release.json`，包含压缩包哈希、验收范围和证据索引哈希。

源码包不带虚拟环境、数据集、基础模型、adapter/checkpoint 或桌面截图。部署依赖原 README 和各阶段说明；查看本地截图和原始日志需另复制对应 output 证据目录。没有自动发布到 GitHub、创建 Git tag 或替换旧交付包。

## 明确保留的限制

| 项目 | 状态 |
|---|---|
| 当前工程测试 | 离线通过，不等价于所有 GUI 任务成功 |
| 本轮真实桌面鲁棒性 | 按用户要求延期，11 种专用窗口场景待测 |
| 真实桌面历史证据 | 此前已有受控应用记录；本轮只读核对，不新增计数 |
| 真实端到端耗时 | 本轮待测；OCR 冷/热基准单独列出 |
| 本地模型质量 | 周三 JSON 可解析性有变化，但动作结构/标注匹配仍未通过 |
| NVIDIA NIM | 真实推理待测，本地 HTTP fixture 不能替代 |
| Windows 200% 与更多应用 | 继续待测；历史 100%/125% 不代表本轮已补测 |

用户本轮明确选择先完成离线验证，以上待测项没有被改写成通过。
